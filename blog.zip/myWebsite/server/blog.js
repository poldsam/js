Blog.config({
	rss:{
		title:'My Portfolio',
		description:'Examples of my work'
	}
});